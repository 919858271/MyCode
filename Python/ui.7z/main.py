# !/usr/bin/env python
# -*- coding: utf-8 -*-
import time
from os import getcwd
from sys import argv, exit
from threading import Thread
from PyQt4 import QtGui, QtCore
from PyQt4.QtGui import QMainWindow
from Ui_client import Ui_Client

def runing_status(runing_signal):
    while True:
        runing_signal.emit('enable.png')
        time.sleep(0.5)
        runing_signal.emit('disable.png')
        time.sleep(0.5)

class Client(QMainWindow, Ui_Client):
    runing_signal = QtCore.pyqtSignal(str)
    def __init__(self, **kwargs):
        QMainWindow.__init__(self)
        self.setupUi(self)
        self.__rebuild_ui()
        self.__call_back()
    
    def __call_back(self):
        self.start_button.clicked.connect(self.set_start)
        self.build_button.clicked.connect(self.set_build)
        self.runing_signal.connect(self.show_info)
        
    def __rebuild_ui(self):
        self.error_statu = 'disable.png'
        self.ok_statu = 'enable.png'
        self.update_status()
    
    def update_status(self, img='---'):
        if img =='---':
            self.ssh.setPixmap(QtGui.QPixmap(self.error_statu))
            self.git_version.setText(img)
            self.code_switch.setText(img)
            self.ebbu.setText(img)
            self.ver_create.setText(img)
            self.prepocess.setText(img)
            self.build_file.setText(img)
        else:
            self.git_version.setPixmap(QtGui.QPixmap(img))
            self.code_switch.setPixmap(QtGui.QPixmap(img))
            self.ebbu.setPixmap(QtGui.QPixmap(img))
            self.ver_create.setPixmap(QtGui.QPixmap(img))
            self.prepocess.setPixmap(QtGui.QPixmap(img))
            self.build_file.setPixmap(QtGui.QPixmap(img))
    
    def show_info(self, info):
        self.update_status(info)
        
    def set_start(self):
        self.runing = Thread(target=runing_status, args=(self.runing_signal,))
        self.runing.daemon = True
        self.runing.start()

    def set_build(self):
        self.update_status(self.ok_statu)
        

def main():
    sys_argv = argv
    app = QtGui.QApplication(sys_argv)
    main_windows = Client()
    main_windows.show()
    exit(app.exec_())


if __name__ == "__main__":
    main()
