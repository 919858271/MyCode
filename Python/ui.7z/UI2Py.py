# !/usr/bin/env python
# -*- coding: utf-8 -*-
# Author:      jianwen
# Email:       npujianwenxu@163.com

import os
for root, dirs, files in os.walk('.'):
    for file in files:
        if file.endswith('.ui'):
            os.system(
                'pyuic.py -o Ui_%s.py -x %s' % (file.rsplit('.', 1)[0], file))
