#!/usr/bin/env python
# -*- coding: utf-8 -*-

SERVER_THOST = ('127.0.0.1', 999)