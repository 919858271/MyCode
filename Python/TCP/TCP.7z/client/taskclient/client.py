#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
import socket
import time
from .config import SERVER_THOST


class TaskClient():

    def __init__(self, server_ip = SERVER_THOST[0], server_port = SERVER_THOST[1]):
        self.client = None
        self.server_ip = server_ip
        self.server_port = server_port
        try:
            self.client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        except socket.error as e:
            print("Error creating socket: %s" % e)
            sys.exit()
        try:
            # self.client.settimeout(5)
            self.client.connect((server_ip, server_port)) 
        except socket.error:
            print('Connect failed!')
            sys.exit()
        self.client.ioctl(socket.SIO_KEEPALIVE_VALS, (1, 1000000, 1))
        self.client.setsockopt(socket.SOL_SOCKET, socket.SO_KEEPALIVE, 1) #开启心跳维护
        self.connected = True

        response = self.client.recv(1024).decode('utf-8')
        if response=='NACK':
            print('Connection Done')
            self.client.close()
            self.connected = False
        if response=='FULL':
            print('Max task processor is reached, please reconnect later.')
            self.client.close()
            self.connected = False
            
        
    def start(self):
        
        while self.connected:
            info = input('Enter message: ')
            if len(info.replace(' ',''))==0:
                continue

            self.client.send(info.encode('utf-8'))
            try:
                response = self.client.recv(1024).decode('utf-8')
            except:
                print('[*] Lost connection with: %s:%d' % (self.server_ip, self.server_port))
                self.client.close()
                self.connected = False
                continue
                
            print(response)
            if response=='NACK':
                print('连接断开')
                self.client.close()
                self.connected = False
                            