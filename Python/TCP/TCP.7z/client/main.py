#!/usr/bin/env python
# -*- coding: utf-8 -*-
from taskclient.client import TaskClient

def main():
    task_client = TaskClient()
    task_client.start()

if __name__ == "__main__":
    main()