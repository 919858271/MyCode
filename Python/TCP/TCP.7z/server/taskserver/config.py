#!/usr/bin/env python
# -*- coding: utf-8 -*-
import os
import sys
from configparser import ConfigParser
class LoadConfig():
    def __init__(self, config_path):

        try:
            self.config=ConfigParser()
            self.config.read(config_path)
        except:
            print('[*] Config file is not found.')
            sys.exit()

        self.ip = self.config.get('server','ip')
        self.port = int(self.config.get('server','port'))
        self.max_connection = int(self.config.get('server','connection'))
