#!/usr/bin/env python
# -*- coding: utf-8 -*-
import os

def kill_task(taskkill, queue, addr):
    print(u'[*] Client: %s:%d lost connection.'%(addr[0], addr[1]))
    queue.get()
    os.system(taskkill)
    print(u"[*] Client:[%s:%d] off line."%(addr[0], addr[1]))
    print(u'[*] Total connected client:%d'% queue.qsize())


def tcp_task(client, addr, task_queue):
    connected = True
    pid = os.getpid()
    taskkill = 'taskkill /pid %d -f' % pid
    connection_lost = u'[*] Client: %s:%d lost connection.'%(addr[0], addr[1])
    
    while connected:

        try:
            request = client.recv(1024).decode('utf-8')
        except:
            kill_task(taskkill, task_queue, addr)
            connected = False
            continue

        if request == 'Q' or len(request) == 0:
            try:
                client.sendall('NACK'.encode('utf-8'))
            except:
                print(connection_lost)
                kill_task(taskkill, task_queue, addr)
                connected = False
                continue
        
        TaskProcess(client, request)
        try:
            client.sendall('ACK'.encode('utf-8'))
        except:
            print(connection_lost)
            
    client.close()


class TaskProcess():
    def __init__(self, client, request):
        print(request)
