#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
import socket
from multiprocessing import Process, Queue
from .task import tcp_task

class TaskServer():

    def __init__(self, configs):   
        self.server = None

        try:
            self.server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        except socket.error as e:
            print("[*] Error creating socket: %s" % e)
            sys.exit()
        self.server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR,1) #重用ip和端口

        try:
            self.server.bind((configs.ip, configs.port))
        except socket.error:
            print('[*] Bind failed!')
            sys.exit()

        self.server.listen(configs.max_connection)
        self.task_queue = Queue(configs.max_connection)
        print('[*] Listening on {ip}:{port}'.format(ip = configs.ip, port = configs.port))

    def start(self):
        while True:
            client, addr = self.server.accept()
            client.ioctl(socket.SIO_KEEPALIVE_VALS, (1, 1000000, 1))
            client.setsockopt(socket.SOL_SOCKET, socket.SO_KEEPALIVE, 1) #开启心跳维护
            if self.task_queue.full():
                try:
                    client.send('FULL'.encode('utf-8'))
                except:
                    print(u'[*] Client: %s:%d lost connection.'%(addr[0], addr[1]))     
            else:
                client_info = {client:{'ip':addr[0], 'port':addr[1], }}
                task = Process(target = tcp_task, args = (client, addr, self.task_queue))
                task.daemon = True
                task.start()

                self.task_queue.put(client_info)
                print(u'[*] Total connected clients:%d' % self.task_queue.qsize())
                print('[*] Accpet new connection from:{ip}:{port}'.format(ip=addr[0], port=addr[1]))
                try:
                    client.sendall('ACK'.encode('utf-8'))
                except:
                    print(u'[*] Client: %s:%d lost connection.'%(addr[0], addr[1])) 
                