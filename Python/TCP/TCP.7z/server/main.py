#!/usr/bin/env python
# -*- coding: utf-8 -*-
import os
from taskserver.server import TaskServer
from taskserver.config import LoadConfig

config_file_name = 'config.ini' 
runing_path = os.path.dirname(os.path.realpath(__file__)).replace('\\','/')
config_path = os.path.normpath(runing_path+'/'+config_file_name).replace('\\','/')

def main():
    configs = LoadConfig(config_path)
    
    task_server = TaskServer(configs)
    task_server.start()

if __name__ == "__main__":
    main()