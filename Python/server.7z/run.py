from threading import Thread
from Task.Task import RapidMakerTask
from Task.TaskManager import TaskManager
from Task.TaskHandler import TaskHandler
from Common.logger import logger

if __name__ == '__main__':
    task = TaskManager(('127.0.0.1', 12306), RapidMakerTask, TaskHandler)
    # task.serve_forever()
    task_thread = Thread(target=task.serve_forever, name='TaskManager')
    task_thread.daemon = True
    task_thread.start()
    logger.info('Listening on %s:%d' % task.server_address)
    while task.is_runing():
        task.help()
