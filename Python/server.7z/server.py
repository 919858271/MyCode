import socketserver
import threading
 
ADDRESS = ('127.0.0.1', 8712)  # 绑定地址
 
g_conn_pool = []  # 连接池
 
 
class ThreadedTCPRequestHandler(socketserver.BaseRequestHandler):
 
    def setup(self):
        self.never_connected = False
        if self.client_address[0] not in g_conn_pool:
            self.request.sendall("连接服务器成功!".encode(encoding='utf8'))
            g_conn_pool.append(self.client_address[0])
            self.never_connected = True
        else:
            self.request.sendall("服务器连接已满".encode(encoding='utf8'))
        
    def handle(self):
        while self.never_connected:
            try:
                bytes = self.request.recv(1024)
                print("客户端消息：", bytes.decode(encoding="utf8"))
            except:
                self.remove()
                break
 
    def finish(self):
        pass
 
    def remove(self):
        print("客户端:%s离线." % self.client_address[0])
        g_conn_pool.remove(self.client_address[0])
 
 
class ThreadedTCPServer(socketserver.ThreadingMixIn, socketserver.TCPServer):
    pass
 

if __name__ == '__main__':
    server = ThreadedTCPServer(ADDRESS, ThreadedTCPRequestHandler)
    # 新开一个线程运行服务端
    server_thread = threading.Thread(target=server.serve_forever)
    server_thread.daemon = True
    server_thread.start()
 
    # 主线程逻辑
    while True:
        cmd = input("""--------------------------
输入1:查看当前在线人数
输入2:给指定客户端发送消息
输入3:关闭服务端
""")
        if cmd == '1':
            print("--------------------------")
            print("当前在线人数：", len(g_conn_pool))
        elif cmd == '2':
            print("--------------------------")
            index, msg = input("请输入“索引,消息”的形式：").split(",")
            g_conn_pool[int(index)].sendall(msg.encode(encoding='utf8'))
        elif cmd == '3':
            server.shutdown()
            server.server_close()
            exit()
