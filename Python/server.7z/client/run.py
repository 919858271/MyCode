#!/usr/bin/env python
# -*- coding: utf-8 -*-
'''
Created on 2019-05-12 17:13:07

@author: xujianwen
'''
from tcp import Client


if __name__ == '__main__':
    client = Client()