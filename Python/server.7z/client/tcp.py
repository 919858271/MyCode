#!/usr/bin/env python
# -*- coding: utf-8 -*-
'''
Created on 2019-05-12 17:04:08

@author: xujianwen
'''
import socket
from config import ADDRESS
from logger import info

class Client():
    
    def __init__(self):
        self.client_socket = socket.socket()
        self.client_socket.connect(ADDRESS)
        self.read()
    
    def read(self):
        info(self.client_socket.recv(1024).decode('utf8'))
        while True:
            msg = input("")
            self.client_socket.send(msg.encode('utf8'))
            
   
    

