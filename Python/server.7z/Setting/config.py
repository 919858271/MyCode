#!/usr/bin/env python
# -*- coding: utf-8 -*-
'''
Created on 2019-05-12 14:14:13

@author: xujianwen
'''
ADDRESS = ('127.0.0.1', 8712)  # 绑定地址