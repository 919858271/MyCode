from Task.Base.Server import ForkServer
from Common.logger import logger

class TaskManager(ForkServer):
    def __init__(self, server_address, TaskClass, TaskHandlerClass):
        self.init_task(TaskClass)
        super(TaskManager, self).__init__(server_address, TaskHandlerClass)

    def init_task(self, TaskClass):
        self.task = TaskClass
        self.init_task_pool()
        self.init_resource()
        self.init_help()

    def init_task_pool(self):
        if self.fork:
            from multiprocessing import Manager
            manager = Manager()
            self.clients = manager.dict()
            self.resources = manager.list()
        else:
            self.clients = dict()
            self.resources = list()

    def init_resource(self):
        for i in range(0, 10):
            self.resources.append(i)
        self.show_resources()

    def init_help(self):
        self.runhelp = {
            'client': self.list_clients,
            'resource': self.show_resources,
            'shutdown': self.server_close,
        }

    def verify_request(self, request, client_address):
        client_id = client_address[0]+str(client_address[1])
        if client_id in self.clients.keys():
            logger.warning(
                'new request from %s:%d will be closed for allready connected.' % self.client_address)
            return False

        return self.alloc_resource(client_address)

    def alloc_resource(self, client_address):
        client_id = client_address[0]+str(client_address[1])
        left_resource = len(self.resources)
        with self.RLock():
            resource = self.resources.pop(0) if left_resource > 0 else None
        if resource is not None:
            self.clients.update({client_id: {'resource': resource}})
            logger.info('accept request from:%s:%d, alloc:%s' %
                        (client_address[0], client_address[1], resource))
            self.show_resources()
            return True
        else:
            logger.critical(
                'not enough resource: left %d share resources' % left_resource)
            return False

    def release_resource(self, client_address):
        client_id = client_address[0]+str(client_address[1])
        client_info = self.clients.pop(client_id, None)
        if client_info is not None:
            self.resources.append(client_info['resource'])

    def show_resources(self):
        logger.info('total available resources:%d' % len(self.resources))
        for resource in self.resources:
            logger.info('available resource: %s' % resource)

    def help(self):
        cmd = input()
        self.runhelp.get(cmd, self.empty)()

    def list_clients(self):
        logger.info('total clients:%d' % len(self.clients))
        for ip, infos in self.clients.items():
            logger.info('client:%s, alloc:%d' % (ip, infos['resource']))

    def empty(self):
        pass
