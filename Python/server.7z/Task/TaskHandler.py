#!/usr/bin/env python
# -*- coding: utf-8 -*-
from Common.logger import logger
from Task.Base.Handler import BaseHandler


class TaskHandler(BaseHandler):
    
    def setup(self):
        self.__runing = True
        self.task = self.server.task()

    def handle(self):
        while self.__runing:
            try:
                msg = self.request.recv(1024).decode('utf8')
                if len(msg) == 0:
                    break
                logger.info(str(msg))
            except:
                self.__runing = False
                break

    def finish(self):
        self.__runing = False
        self.server.release_resource(self.client_address)
        self.server.shutdown_request(self.request)
        logger.info('request from %s:%d shutdown' % self.client_address)
