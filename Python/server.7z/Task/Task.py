
class RapidMakerTask():
    pass
