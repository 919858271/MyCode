#!/usr/bin/env python
# -*- coding: utf-8 -*-
'''
Created on 2019-05-12 14:14:34

@author: xujianwen
'''
import random
from logger import info
class SinglePattern():
    def __new__(cls, *args, **kwargs):
        if not hasattr(cls, '_instance'):
            cls._instance = super(SinglePattern, cls).__new__(cls)
        return cls._instance

class ResourcePool(SinglePattern):
    
    def __init__(self):
        self.__rlock = list()
        self.__lock  = dict()
        self.init_resource()
        
    def init_resource(self):
        data = {
               'path':'',
               'cmac_dirs':{},
               'scripts1':random.random()+1,
               'scripts2':random.random()+2,
               'scripts3':random.random()+3,
               }
        self.__rlock.append(data)

    def get_resource(self, tag):
        resource = self.__rlock.pop(0) if len(self.__rlock) > 0 else None
        if resource is not None:
            self.__lock.update({tag:resource})
        return resource
    
    def release_resource(self, tag):
        resource = self.__lock.pop(tag, None)
        if resource:
            self.__rlock.append(resource)
            return True
        return False

class ClientPool(ResourcePool):
    
    clients= dict()
    def update(self, ip):
        resource = self.get_resource(ip)
        if resource is not None:
            self.clients.update({ip:resource})
            return True
        return False

    def pop(self, ip):
        if self.release_resource(ip):
            self.clients.pop(ip)
            return True
        return False
    
    
