#!/usr/bin/env python
# -*- coding: utf-8 -*-
'''
Created on 2019-05-12 13:58:54

@author: xujianwen
'''
from pool import ClientPool
from logger import info
class Help():
    
    def __init__(self, server):
        self.client_pool = ClientPool()
        self.server = server
        self.run = {
                    'client':self.__client_list,
                    'close':self.__close_server}
    
    def __new__(cls, *args, **kwargs):
        if not hasattr(cls, '_instance'):
            cls._instance = super(Help, cls).__new__(cls)
        return cls._instance
    
    
    def __client_list(self):
        
        info('=========Client list==============')
        for client in self.client_pool.clients:
            info("= Connected client：%s " % client)
        info('=========Client list==============')
    def __close_server(self):
        self.server.shutdown()
        self.server.server_close()
        exit(0)
    
    
    @staticmethod
    def usage():
        info('===============Help===============')
        info('= client:查看当前连接客户端      =')
        info('===============Help===============')
        
    def empty(self):
        info('=========Commond not found========')
        
        
        
            