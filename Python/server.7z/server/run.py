#!/usr/bin/env python
# -*- coding: utf-8 -*-
'''
Created on 2019-05-12 13:53:08

@author: xujianwen
'''
import threading
from help import Help
from logger import info
from config import ADDRESS
from tcp import ThreadedTCPServer
from tcp import ThreadedTCPRequestHandler

if __name__ == '__main__':
    server = ThreadedTCPServer(ADDRESS, ThreadedTCPRequestHandler)
    server_thread = threading.Thread(target=server.serve_forever)
    server_thread.daemon = True
    server_thread.start()
    info(u'============服务启动成功==========')

    helps = Help(server)
    while True:
        helps.usage()
        cmd = input()
        helps.run.get(cmd, helps.empty)()
        
