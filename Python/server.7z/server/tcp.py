#!/usr/bin/env python
# -*- coding: utf-8 -*-
'''
Created on 2019-05-12 13:51:03

@author: xujianwen
'''
import socketserver
from logger import info, warning, critical
from help import Help
from pool import ClientPool

class ThreadedTCPRequestHandler(socketserver.BaseRequestHandler):
    
    client_pool = ClientPool()
    
    def set_connected(self):
        if self.client_pool.update(self.client_address[0]):
            self.never_connected = True
            self.request.sendall('ACK:接入成功'.encode('utf8'))
            info("客户端:%s 接入成功." % self.client_address[0])
        else:
            self.request.sendall('NACK:无可用资源'.encode('utf8'))
            critical('无可用资源.')
        Help.usage()
        
    def client_not_conected(self):
        return self.client_address[0] not in self.client_pool.clients.keys()
    
    def remove(self):
        if self.client_pool.pop(self.client_address[0]):
            info("客户端:%s 离线." % self.client_address[0])
        else:
            critical("客户端:%s 资源释放失败." % self.client_address[0])
        Help.usage()
        
    def setup(self):
        self.never_connected = False
        if self.client_not_conected():
            self.set_connected()
        else:
            self.request.sendall('NACK:客户端存在已连接.'.encode('utf8'))
            return
        
    def handle(self):
        while self.never_connected:
            try:
                msg = self.request.recv(1024)
                if not msg:
                    info('rcv empty data and will remove the connection from %s' % self.client_address[0])
                    self.remove()
                    break
                info("客户端消息：%s"% msg.decode(encoding="utf8"))
            except:
                self.remove()
                break
 
    def finish(self):
        pass

class ThreadedTCPServer(socketserver.ThreadingMixIn, socketserver.TCPServer):
    pass
 

