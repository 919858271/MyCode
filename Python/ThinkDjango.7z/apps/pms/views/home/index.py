#!/usr/bin/env python
# -*- coding: utf-8 -*-
'''

Created on 2019-02-04 12:08:57

@author: jianwen

'''
import json
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.db.models import Q
from django.http import HttpResponse
from django.shortcuts import render, redirect
from django.views.decorators.http import require_http_methods

from apps.pms.format.time2json import JsonEncoder
from ...models import Requirement, EpicStory, UserStory


@require_http_methods(['POST', 'GET'])
def login_by(request):
    if request.method == 'POST':
        username = request.POST.get('username', '')
        password = request.POST.get('password', '')
        user = authenticate(username=username, password=password)
        redirect_to = request.POST.get('next', '/')
        if user and user.is_active:
            login(request, user)
            return redirect(redirect_to or '/')
        else:
            return redirect('/login/?next=%s' % redirect_to)

    return render(request, 'pms/home/login.html')


def logout_by(request):
    logout(request)
    return redirect('/login/')


@login_required(login_url='/login/')
def index(request):
    user = request.user
    return render(request, 'pms/home/index.html', {'user': user})


@require_http_methods(['POST'])
@login_required(login_url='/login/')
def requirements_need_to_do(request):
    user = request.user
    condition = Q(status=0) & (Q(creater=user) | Q(assigned_to=user))

    select_filed = {'id': 'requirement_id',
                    'name': 'name',
                    'auth': 'creater',
                    'worker': 'assigned_to',
                    'type': 'task_type',
                    'time': 'end_time'}

    requirements = Requirement.objects.extra(select=select_filed).values(*(select_filed.keys())).filter(condition).distinct().order_by('-time')
    response = {'total': requirements.count(), 'rows': list(requirements)}
    return HttpResponse(json.dumps(response, cls=JsonEncoder))


@require_http_methods(['POST'])
@login_required(login_url='/login/')
def epic_story_need_to_do(request):
    user = request.user
    condition = Q(status=0), Q(creater=user) | Q(assigned_to=user)

    select_filed = {'id': 'epic_story_id',
                    'name': 'name',
                    'auth': 'creater',
                    'worker': 'assigned_to',
                    'type': 'task_type',
                    'time': 'end_time'}

    epic_story = EpicStory.objects.extra(select=select_filed).values(*(select_filed.keys())).filter(condition).distinct().order_by('-time')
    response = {'total': epic_story.count(), 'rows': list(epic_story)}
    return HttpResponse(json.dumps(response, cls=JsonEncoder))


@require_http_methods(['POST'])
@login_required(login_url='/login/')
def user_story_need_to_do(request):
    user = request.user
    condition = Q(status=0), Q(creater=user) | Q(assigned_to=user)

    select_filed = {'id': 'user_story_id',
                    'name': 'name',
                    'auth': 'creater',
                    'worker': 'assigned_to',
                    'type': 'task_type',
                    'time': 'end_time'}

    user_story = UserStory.objects.extra(select=select_filed).values(*(select_filed.keys())).filter(condition).distinct().order_by('-time')
    response = {'total': user_story.count(), 'rows': list(user_story)}
    return HttpResponse(json.dumps(response, cls=JsonEncoder))


@login_required(login_url='/login/')
def task_need_to_do(request):
    user = request.user
    return render(request, 'pms/home/task.html', {'user': user})
