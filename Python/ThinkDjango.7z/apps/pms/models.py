from django.db import models
from django.utils import timezone


class Task(models.Model):
    name = models.CharField(max_length=200,
                            verbose_name=u'任务名称',
                            null=False)
    creater = models.CharField(max_length=10,
                               verbose_name=u'创建者',
                               null=False)
    assigned_to = models.CharField(max_length=20,
                                   verbose_name=u'当前处理人',
                                   null=False)
    end_time = models.DateTimeField(default=timezone.now,
                                    verbose_name=u'截止时间',
                                    null=False)
    is_new_assigned = models.IntegerField(choices=((0, u'非新增'), (1, u'新增')),
                                          verbose_name=u'创建状态',
                                          default=1,
                                          null=True)
    task_type = models.IntegerField(choices=((0, u'项目需求'), (1, u'团队任务')),
                                    verbose_name=u'需求类型',
                                    default=0,
                                    null=True)
    remark = models.CharField(max_length=200,
                              verbose_name=u'备注',
                              null=True)
    status = models.IntegerField(choices=((0, u'未完成'), (1, u'完成')),
                                 verbose_name=u'完成状态',
                                 default=0,
                                 null=False)

    class Meta:
        abstract = True


class Requirement(Task):
    requirement_id = models.CharField(max_length=20,
                                      verbose_name=u'需求编号',
                                      null=False,
                                      unique=True)

    def __str__(self):
        return self.requirement_id+': '+self.name

    class Meta:
        verbose_name = u'需求'
        verbose_name_plural = u'需求'


class EpicStory(Task):
    epic_story_id = models.CharField(max_length=20,
                                     verbose_name=u'史诗编号',
                                     null=False,
                                     unique=True)
    requirement = models.ForeignKey(Requirement,
                                    to_field='requirement_id',
                                    on_delete=models.CASCADE,
                                    verbose_name=u'需求',
                                    null=False)

    def __str__(self):
        return self.epic_story_id+': '+self.name

    class Meta:
        verbose_name = u'史诗故事'
        verbose_name_plural = u'史诗故事'


class UserStory(Task):
    user_story_id = models.CharField(max_length=20,
                                     verbose_name=u'用户故事编号',
                                     null=False,
                                     unique=True
                                     )
    epic_story = models.ForeignKey(EpicStory,
                                   to_field='epic_story_id',
                                   on_delete=models.CASCADE,
                                   verbose_name=u'史诗',
                                   null=False)

    def __str__(self):
        return self.user_story_id+': '+self.name

    class Meta:
        verbose_name = u'用户故事'
        verbose_name_plural = u'用户故事'
