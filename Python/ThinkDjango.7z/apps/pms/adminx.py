from django.contrib import admin
import xadmin
from .models import Requirement, EpicStory, UserStory

# Register your models here.
admin.site.site_header = u'PMS后台系统'
admin.site.site_title = 'PMS系统'


@xadmin.sites.register(Requirement)
class RequirementAdmin(object):

    list_display = ('requirement_id',
                    'name',
                    'creater',
                    'assigned_to',
                    'end_time')
    list_per_page = 50
    search_fields = ['requirement_id',
                     'name',
                     'creater',
                     'assigned_to',
                     'end_time']
    fields = search_fields
    model_icon = 'fa fa-user'


@xadmin.sites.register(EpicStory)
class EpicStorydAdmin(object):

    list_display = ('epic_story_id',
                    'name',
                    'creater',
                    'assigned_to',
                    'end_time',
                    'requirement')
    list_per_page = 50
    search_fields = ['epic_story_id',
                     'name',
                     'creater',
                     'assigned_to',
                     'end_time',
                     'requirement']
    fields = search_fields
    model_icon = 'fa fa-user'


@xadmin.sites.register(UserStory)
class UserStorydAdmin(object):

    list_display = ('user_story_id',
                    'name',
                    'creater',
                    'assigned_to',
                    'end_time',
                    'epic_story')
    list_per_page = 50
    search_fields = ['user_story_id',
                     'name',
                     'creater',
                     'assigned_to',
                     'end_time',
                     'epic_story']
    fields = search_fields
    model_icon = 'fa fa-user'
