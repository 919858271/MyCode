#!/usr/bin/env python
# -*- coding: utf-8 -*-
'''

Created on 2019-02-05 18:56:41

@author: jianwen

'''
from datetime import datetime, date
import json


class JsonEncoder(json.JSONEncoder):
    def default(self, obj):
        try:
            if isinstance(obj, (datetime, date,)):
                return obj.strftime('%Y-%m-%d %H:%M:%S')
            else:
                return json.JSONEncoder.default(self, obj)
        except Exception as e:
            print(e)
